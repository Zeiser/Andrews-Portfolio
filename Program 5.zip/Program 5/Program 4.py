# -------------------------------------------------------------
# Author:
# Andrew Zeiser
# Program: Program 5
# Description: 
# To display your employee billing records. 
# ------------------------------------------------------------

import BillingModule




def main():
    loopControl = True
    while loopControl:
        print('\nBilling System Menu:\n')
        print('\t0 - end')
        print('\t1 - Enter billing data')
        print('\t2 - Display ad-hoc billing report')

        option = int(input('\nOption ==> '))

        if option == 0:
            loopControl = False
            print('Program has ended.')
        elif option == 1:
            BillingModule.billingEntry()
        elif option == 2:
            BillingModule.readBillingRecords()
        else:
            print('Please enter an available option.\n')

main()
    
   

